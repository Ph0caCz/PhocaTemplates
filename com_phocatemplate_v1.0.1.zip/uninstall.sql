DROP TABLE IF EXISTS `#__phocatemplate_menus`;
DROP TABLE IF EXISTS `#__phocatemplate_columns`;
